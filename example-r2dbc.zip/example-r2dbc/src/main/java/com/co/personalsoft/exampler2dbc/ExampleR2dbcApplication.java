package com.co.personalsoft.exampler2dbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleR2dbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleR2dbcApplication.class, args);
	}

}
