package com.co.personalsoft.exampler2dbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleR2dbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
